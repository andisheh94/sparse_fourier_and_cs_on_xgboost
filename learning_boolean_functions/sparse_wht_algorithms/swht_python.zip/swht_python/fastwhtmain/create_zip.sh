#! /bin/sh

rm -f fastwht_python.zip
rm -f fastwht_matlab.zip

zip -r fastwht_python.zip python
zip -r fastwht_matlab.zip matlab


